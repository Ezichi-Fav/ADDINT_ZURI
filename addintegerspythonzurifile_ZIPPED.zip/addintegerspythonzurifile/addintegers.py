#a = 5
#b = 6
#total_num = a + b
#print (total_num)

print ("what numbers do you want to add")  
    
first_num = int (input ("Enter first number : "))

second_num = int(input ("Enter second number : "))

sum_integers = first_num + second_num
print ( sum_integers)
 